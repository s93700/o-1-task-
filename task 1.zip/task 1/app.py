from flask import Flask, render_template

app = Flask(__name__)

@app.route('/url/task')
def task_page():
    # Define dynamic data
    task_data = {
        'task_name': 'Complete Project',
        'task_description': 'Finish the project by the deadline.',
        'task_priority': 'High'
    }

    # Render the template with dynamic data
    return render_template('task.html', task=task_data)

if __name__ == '__main__':
    app.run(debug=True)
